module.exports = {
 consumer_key:         'G6ubzvugzkTH9LTNElk9VekNt',
  consumer_secret:      'UsaGUWdKe5jcEiqR3S6bWCJNZstcbsxpsNkBjQl3bs0tXcmhS0',
  access_token:         '1062323182701559810-5vPYp5BQfcfZWdbN82yeUY5Fv3Besz',
  access_token_secret:  '36OscsHrjMOPeTrUQNvTwLxMhlqnjioBvNfQ3em8QrEIj'
}